import React, { useMemo, useRef } from "react";
import type { NotionGraphNode, Vec } from "../types";
import { clientToWorld } from "../lib/coords";

function wrapTitleToLines(title: string, diameterPx: number, maxLines = 3) {
  const clean = (title || "").trim();
  if (!clean) return { lines: [""], fontSize: 14 };

  const fontSize = Math.max(12, Math.min(18, diameterPx * 0.20));
  const avg = 0.54;
  const maxChars = Math.max(6, Math.floor((diameterPx * 0.78) / (fontSize * avg)));

  const words = clean.split(/\s+/);
  const lines: string[] = [];
  let cur = "";

  for (const w of words) {
    if ((cur ? cur.length + 1 : 0) + w.length <= maxChars) cur = cur ? cur + " " + w : w;
    else {
      if (cur) lines.push(cur);
      cur = w;
      if (lines.length === maxLines - 1) break;
    }
  }
  if (lines.length < maxLines && cur) lines.push(cur);
  if (lines.length === maxLines && words.join(" ").length > lines.join(" ").length) {
    const last = lines[lines.length - 1];
    if (last.length > 3) lines[lines.length - 1] =
      last.slice(0, Math.max(0, maxChars - 1)).trimEnd() + "…";
  }

  return { lines, fontSize };
}

export const NodeItem: React.FC<{
  id: string;
  node: NotionGraphNode;

  posScreen: Vec;
  sizeScreen: number;

  sizeWorld: number;

  containerRef: React.RefObject<HTMLDivElement>;
  scale: number;
  pan: Vec;

  onPinStart: (id: string, p: Vec) => void;
  onPinMove: (id: string, p: Vec) => void;
  onPinEnd: (id: string, p: Vec, v: { vx: number; vy: number }) => void;

  onToggle: (id: string) => void;
  canToggle?: boolean;

  fill?: string;
  stroke?: string;
  labelColor?: string;
}> = ({
  id,
  node,
  posScreen,
  sizeScreen,
  sizeWorld,
  containerRef,
  scale,
  pan,
  onPinStart,
  onPinMove,
  onPinEnd,
  onToggle,
  canToggle = true,
  fill = "#ffffff",
  stroke = "rgba(0,0,0,0.18)",
  labelColor = "#111827",
}) => {
  const pointer = useRef<{ x: number; y: number; t: number }>({ x: 0, y: 0, t: 0 });
  const last = useRef<Vec>({ x: 0, y: 0 });
  const dragging = useRef(false);
  const clickTimeout = useRef<number | null>(null);

  const title = useMemo(() => node.title || node.name || id, [node.title, node.name, id]);
  const wrapped = useMemo(() => wrapTitleToLines(title, sizeScreen), [title, sizeScreen]);

  const toWorldTopLeft = (clientX: number, clientY: number): Vec => {
    const rect = containerRef.current?.getBoundingClientRect() ?? null;
    const wc = clientToWorld(clientX, clientY, rect, pan, scale);
    return { x: wc.x - sizeWorld / 2, y: wc.y - sizeWorld / 2 };
    };

  const onMouseDown: React.MouseEventHandler<HTMLDivElement> = (e) => {
    e.stopPropagation();
    const p = toWorldTopLeft(e.clientX, e.clientY);
    pointer.current = { x: e.clientX, y: e.clientY, t: performance.now() };
    last.current = p;

    const move = (ev: MouseEvent) => {
      const np = toWorldTopLeft(ev.clientX, ev.clientY);
      const dx = ev.clientX - pointer.current.x;
      const dy = ev.clientY - pointer.current.y;
      const dist = Math.hypot(dx, dy);
      if (!dragging.current && dist > 2) {
        dragging.current = true;
        onPinStart(id, last.current);
      }
      if (dragging.current) onPinMove(id, np);
      last.current = np;
    };

    const up = (ev: MouseEvent) => {
      window.removeEventListener("mousemove", move);
      window.removeEventListener("mouseup", up);

      const dt = Math.max(1, performance.now() - pointer.current.t);
      const np = toWorldTopLeft(ev.clientX, ev.clientY);
      const vx = ((np.x - last.current.x) / dt) * 16.7;
      const vy = ((np.y - last.current.y) / dt) * 16.7;

      if (dragging.current) {
        dragging.current = false;
        onPinEnd(id, np, { vx, vy });
        return;
      }

      if (clickTimeout.current) {
        window.clearTimeout(clickTimeout.current);
        clickTimeout.current = null;
        if (node.url) window.open(node.url, "_blank", "noopener");
      } else {
        clickTimeout.current = window.setTimeout(() => {
          clickTimeout.current = null;
          if (canToggle) onToggle(id);
        }, 180);
      }
    };

    window.addEventListener("mousemove", move);
    window.addEventListener("mouseup", up);
  };

  const lineHeight = wrapped.fontSize * 1.12;
  const startY = sizeScreen / 2 - ((wrapped.lines.length - 1) * lineHeight) / 2;

  return (
    <div
      className="node-ball"
      onMouseDown={onMouseDown}
      style={{
        position: "absolute",
        left: posScreen.x,
        top: posScreen.y,
        width: sizeScreen,
        height: sizeScreen,
        background: "transparent",
        userSelect: "none",
        cursor: "grab",
      }}
      title={title}
    >
      <svg
        width={sizeScreen}
        height={sizeScreen}
        style={{ display: "block" }}
        shapeRendering="geometricPrecision"
        textRendering="optimizeLegibility"
      >
        <circle
          cx={sizeScreen / 2}
          cy={sizeScreen / 2}
          r={(sizeScreen - 4) / 2}
          fill={fill}
          stroke={stroke}
          strokeWidth={2}
          vectorEffect="non-scaling-stroke"
        />
        <g
          fontFamily='Inter Variable, Inter, system-ui, -apple-system, "Segoe UI", Roboto, Helvetica, Arial'
          fontWeight={600}
          style={{ fontKerning: "normal" as any, fontVariationSettings: "'wght' 600" }}
        >
          {wrapped.lines.map((ln, i) => (
            <text
              key={i}
              x="50%"
              y={startY + i * lineHeight}
              dominantBaseline="middle"
              textAnchor="middle"
              fill={labelColor}
              style={{ fontSize: wrapped.fontSize, letterSpacing: 0.1 }}
            >
              {ln}
            </text>
          ))}
        </g>
      </svg>
    </div>
  );
};
