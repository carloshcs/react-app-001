import React, { useMemo, useRef } from "react";

/** Local light types to avoid cross-file coupling */
type Vec = { x: number; y: number };
type NotionGraphNode = {
  id: string;
  title?: string;
  name?: string;
  url?: string | null;
};

function clientToWorld(
  clientX: number,
  clientY: number,
  container: HTMLDivElement | null,
  pan: Vec,
  scale: number
): Vec {
  const rect = container?.getBoundingClientRect() ?? {
    left: 0,
    top: 0,
  } as DOMRect;
  const sx = clientX - rect.left;
  const sy = clientY - rect.top;
  return { x: (sx - pan.x) / scale, y: (sy - pan.y) / scale };
}

function wrapTitleToLines(title: string, diameterPx: number, maxLines = 3) {
  const clean = (title || "").trim();
  if (!clean) return { lines: [""], fontSize: 14 };

  const fontSize = Math.max(12, Math.min(18, diameterPx * 0.2));
  const avg = 0.54;
  const maxChars = Math.max(6, Math.floor((diameterPx * 0.78) / (fontSize * avg)));

  const words = clean.split(/\s+/);
  const lines: string[] = [];
  let cur = "";

  for (const w of words) {
    if ((cur ? cur.length + 1 : 0) + w.length <= maxChars) cur = cur ? cur + " " + w : w;
    else {
      if (cur) lines.push(cur);
      cur = w;
      if (lines.length === maxLines - 1) break;
    }
  }
  if (lines.length < maxLines && cur) lines.push(cur);
  if (lines.length === maxLines && words.join(" ").length > lines.join(" ").length) {
    const last = lines[lines.length - 1];
    if (last.length > 3)
      lines[lines.length - 1] = last.slice(0, Math.max(0, maxChars - 1)).trimEnd() + "…";
  }

  return { lines, fontSize };
}

export const NodeItem: React.FC<{
  id: string;
  node: NotionGraphNode;

  posScreen: Vec;
  sizeScreen: number;

  sizeWorld: number;

  containerRef: React.RefObject<HTMLDivElement>;
  scale: number;
  pan: Vec;

  onPinStart: (id: string, p: Vec) => void;
  onPinMove: (id: string, p: Vec) => void;
  onPinEnd: (id: string, p: Vec, v: { vx: number; vy: number }) => void;

  onToggle: (id: string) => void;
  canToggle?: boolean;

  fill?: string;
  stroke?: string;
  labelColor?: string;
}> = ({
  id,
  node,
  posScreen,
  sizeScreen,
  sizeWorld,
  containerRef,
  scale,
  pan,
  onPinStart,
  onPinMove,
  onPinEnd,
  onToggle,
  canToggle = true,
  fill = "#ffffff",
  stroke = "rgba(0,0,0,0.18)",
  labelColor = "#111827",
}) => {
  const clickTimeout = useRef<number | null>(null);
  const dragging = useRef(false);
  const start = useRef<{ x: number; y: number; t: number }>({ x: 0, y: 0, t: 0 });
  const lastWorld = useRef<Vec>({ x: 0, y: 0 });

  const title = useMemo(() => node.title || node.name || id, [node.title, node.name, id]);
  const wrapped = useMemo(() => wrapTitleToLines(title, sizeScreen), [title, sizeScreen]);

  const toWorldTopLeft = (clientX: number, clientY: number): Vec => {
    const wc = clientToWorld(clientX, clientY, containerRef.current, pan, scale);
    return { x: wc.x - sizeWorld / 2, y: wc.y - sizeWorld / 2 };
  };

  const onMouseDown: React.MouseEventHandler<HTMLDivElement> = (e) => {
    if (e.button !== 0) return; // left click only
    e.stopPropagation();

    const p = toWorldTopLeft(e.clientX, e.clientY);
    start.current = { x: e.clientX, y: e.clientY, t: performance.now() };
    lastWorld.current = p;
    dragging.current = false;

    const move = (ev: MouseEvent) => {
      const dx = ev.clientX - start.current.x;
      const dy = ev.clientY - start.current.y;
      const dist = Math.hypot(dx, dy);

      const np = toWorldTopLeft(ev.clientX, ev.clientY);
      if (!dragging.current && dist > 2) {
        dragging.current = true;
        onPinStart(id, lastWorld.current);
      }
      if (dragging.current) {
        onPinMove(id, np);
        lastWorld.current = np;
      }
    };

    const up = (ev: MouseEvent) => {
      window.removeEventListener("mousemove", move);
      window.removeEventListener("mouseup", up);

      const dt = Math.max(1, performance.now() - start.current.t);
      const np = toWorldTopLeft(ev.clientX, ev.clientY);
      const vx = ((np.x - lastWorld.current.x) / dt) * 16.7;
      const vy = ((np.y - lastWorld.current.y) / dt) * 16.7;

      if (dragging.current) {
        dragging.current = false;
        onPinEnd(id, np, { vx, vy });
        return;
      }

      // Click (no drag) — differentiate single vs double
      if (clickTimeout.current) {
        // Double click -> open link
        window.clearTimeout(clickTimeout.current);
        clickTimeout.current = null;
        if (node.url) window.open(node.url, "_blank", "noopener");
      } else {
        // Single click -> toggle
        clickTimeout.current = window.setTimeout(() => {
          clickTimeout.current = null;
          if (canToggle) onToggle(id);
        }, 200);
      }
    };

    window.addEventListener("mousemove", move);
    window.addEventListener("mouseup", up);
  };

  const lineHeight = wrapped.fontSize * 1.12;
  const startY = sizeScreen / 2 - ((wrapped.lines.length - 1) * lineHeight) / 2;

  return (
    <div
      className="node-ball"
      onMouseDown={onMouseDown}
      style={{
        position: "absolute",
        left: posScreen.x,
        top: posScreen.y,
        width: sizeScreen,
        height: sizeScreen,
        background: "transparent",
        userSelect: "none",
        cursor: "grab",
        zIndex: 2, // above links
      }}
      title={title}
    >
      <svg
        width={sizeScreen}
        height={sizeScreen}
        style={{ display: "block" }}
        shapeRendering="geometricPrecision"
        textRendering="optimizeLegibility"
      >
        <circle
          cx={sizeScreen / 2}
          cy={sizeScreen / 2}
          r={(sizeScreen - 4) / 2}
          fill={fill}
          stroke={stroke}
          strokeWidth={2}
          vectorEffect="non-scaling-stroke"
        />
        <g
          fontFamily='Inter Variable, Inter, system-ui, -apple-system, "Segoe UI", Roboto, Helvetica, Arial'
          fontWeight={600}
          style={{ fontKerning: "normal" as any, fontVariationSettings: "'wght' 600" }}
        >
          {wrapped.lines.map((ln, i) => (
            <text
              key={i}
              x="50%"
              y={startY + i * lineHeight}
              dominantBaseline="middle"
              textAnchor="middle"
              fill={labelColor}
              style={{ fontSize: wrapped.fontSize, letterSpacing: 0.1 }}
            >
              {ln}
            </text>
          ))}
        </g>
      </svg>
    </div>
  );
};
